#include "sd_logger.h"

#include "../config/system_config.h"

bool SdLogger::begin(uint8_t chipSelectPin) {
  cardReady_ = SD.begin(chipSelectPin);
  return cardReady_;
}

bool SdLogger::openForDate(uint8_t month, uint8_t day) {
  if (!cardReady_ || ready_) return ready_;
  ready_ = createUniqueFile(month, day);
  if (ready_) {
    usingFallbackDate_ = month == 0 && day == 0;
    writeHeader();
    file_.flush();
  }
  return ready_;
}

bool SdLogger::reopenWithGpsDate(uint8_t month, uint8_t day) {
  if (!cardReady_ || !ready_ || !usingFallbackDate_ || month == 0 || day == 0)
    return ready_;
  // Keep early rows in P0000_NN.CSV, then continue in the dated file once the
  // GPS has supplied a valid UTC date.
  file_.flush();
  file_.close();
  ready_ = false;
  return openForDate(month, day);
}

bool SdLogger::createUniqueFile(uint8_t month, uint8_t day) {
  for (uint16_t index = 0; index <= 999; ++index) {
    // The bundled SD library uses 8.3 names. PMMDDNNN.CSV is the readable
    // on-card equivalent of payload_srad_MMDD_NNN.csv.
    snprintf(filename_, sizeof(filename_), "P%02u%02u%03u.CSV", month, day,
             index);
    if (!SD.exists(filename_)) {
      file_ = SD.open(filename_, FILE_WRITE);
      return static_cast<bool>(file_);
    }
  }
  return false;
}

void SdLogger::writeHeader() {
  file_.println(
      F("t_ms,mode,imu_valid,qw,qx,qy,qz,yaw_deg,pitch_deg,roll_deg,"
        "blocker,local_baro_valid,local_baro_reference_valid,local_pressure_pa,local_temp_c,local_agl_m,local_reference_pa,"
        "local_gps_valid,local_itow_ms,local_lat_i7,local_lon_i7,"
        "local_hmsl_mm,local_fix_type,local_num_sv,"
        "remote_valid,remote_seq,remote_itow_ms,remote_lat_i7,remote_lon_i7,"
        "remote_agl_m,remote_vel_n_mps,remote_vel_e_mps,remote_vel_d_mps,remote_fix_type,"
        "initial_baro_bias_m,baro_bias_ready,rel_n_m,rel_e_m,rel_d_m,rel_up_m,range_m,target_yaw_deg,target_pitch_deg,"
        "gimbal_yaw_cmd,gimbal_pitch_cmd,gimbal_yaw_cmd_unwrapped,gimbal_yaw_pos,gimbal_pitch_pos,gimbal_yaw_pos_unwrapped,"
        "gimbal_cur_y,gimbal_cur_p,gimbal_temp_y,gimbal_temp_p,gimbal_feedback_us,gimbal_feedback_max_us,gimbal_feedback_slow_count,control_interval_us,control_interval_max_us,control_overrun_count,"
        "gimbal_limit,gimbal_torque"));
}

void SdLogger::log(uint32_t nowMs, TrackMode mode, TrackingBlocker blocker,
                   const AttitudeSample& attitude,
                   const BarometerSample& localBaro, const GpsFix& localGps,
                   const RemoteTargetSample& remote,
                   const RelativeTarget& relative,
                   const GimbalState& gimbal, float initialBaroBiasM,
                   bool baroBiasReady) {
  if (!ready_) return;

#define CSV_VALUE(...)      \
  do {                      \
    file_.print(__VA_ARGS__); \
    file_.print(',');       \
  } while (0)

  CSV_VALUE(nowMs);
  CSV_VALUE(static_cast<uint8_t>(mode));
  CSV_VALUE(attitude.valid ? 1 : 0);
  CSV_VALUE(attitude.q[0], 6);
  CSV_VALUE(attitude.q[1], 6);
  CSV_VALUE(attitude.q[2], 6);
  CSV_VALUE(attitude.q[3], 6);
  CSV_VALUE(attitude.yawDeg, 3);
  CSV_VALUE(attitude.pitchDeg, 3);
  CSV_VALUE(attitude.rollDeg, 3);
  CSV_VALUE(static_cast<uint8_t>(blocker));
  CSV_VALUE(localBaro.valid ? 1 : 0);
  CSV_VALUE(localBaro.referenceValid ? 1 : 0);
  CSV_VALUE(localBaro.pressurePa, 2);
  CSV_VALUE(localBaro.temperatureC, 2);
  CSV_VALUE(localBaro.aglM, 3);
  CSV_VALUE(localBaro.referencePressurePa, 2);
  CSV_VALUE(localGps.valid ? 1 : 0);
  CSV_VALUE(localGps.iTowMs);
  CSV_VALUE(localGps.latI7);
  CSV_VALUE(localGps.lonI7);
  CSV_VALUE(localGps.hMslMm);
  CSV_VALUE(localGps.fixType);
  CSV_VALUE(localGps.numSv);
  CSV_VALUE(remote.valid ? 1 : 0);
  CSV_VALUE(remote.sequence);
  CSV_VALUE(remote.senderITowMs);
  CSV_VALUE(remote.latI7);
  CSV_VALUE(remote.lonI7);
  CSV_VALUE(remote.aglM, 3);
  CSV_VALUE(remote.velNMps, 3);
  CSV_VALUE(remote.velEMps, 3);
  CSV_VALUE(remote.velDMps, 3);
  CSV_VALUE(remote.fixType);
  CSV_VALUE(initialBaroBiasM, 3);
  CSV_VALUE(baroBiasReady ? 1 : 0);
  CSV_VALUE(relative.northM, 3);
  CSV_VALUE(relative.eastM, 3);
  CSV_VALUE(relative.downM, 3);
  CSV_VALUE(relative.valid ? -relative.downM : 0.0f, 3);
  CSV_VALUE(relative.rangeM, 3);
  CSV_VALUE(relative.yawDeg, 3);
  CSV_VALUE(relative.pitchDeg, 3);
  CSV_VALUE(gimbal.yawCommandDeg, 3);
  CSV_VALUE(gimbal.pitchCommandDeg, 3);
  CSV_VALUE(gimbal.yawCommandUnwrappedDeg, 3);
  CSV_VALUE(gimbal.yawPresentDeg, 3);
  CSV_VALUE(gimbal.pitchPresentDeg, 3);
  CSV_VALUE(gimbal.yawPresentUnwrappedDeg, 3);
  CSV_VALUE(gimbal.yawCurrentRaw);
  CSV_VALUE(gimbal.pitchCurrentRaw);
  CSV_VALUE(gimbal.yawTemperatureC);
  CSV_VALUE(gimbal.pitchTemperatureC);
  CSV_VALUE(gimbal.lastFeedbackUs);
  CSV_VALUE(gimbal.maxFeedbackUs);
  CSV_VALUE(gimbal.slowFeedbackCount);
  CSV_VALUE(gimbal.lastControlIntervalUs);
  CSV_VALUE(gimbal.maxControlIntervalUs);
  CSV_VALUE(gimbal.controlOverrunCount);
  CSV_VALUE(gimbal.limitActive ? 1 : 0);
  file_.println(gimbal.torqueOn ? 1 : 0);

#undef CSV_VALUE

  if (file_.getWriteError()) {
    ++writeErrors_;
    file_.clearWriteError();
  } else {
    ++rowsWritten_;
  }
}

void SdLogger::service(uint32_t nowMs) {
  if (!ready_) return;
  if (static_cast<uint32_t>(nowMs - lastFlushMs_) >=
      cfg::SD_FLUSH_PERIOD_MS) {
    file_.flush();
    lastFlushMs_ = nowMs;
  }
}
